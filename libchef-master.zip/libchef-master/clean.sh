#/bin/bash

set -x

rm -rf output
